/*
 * Copyright (c) 2018-2023 REV Robotics
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of REV Robotics nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#include "rev/SparkMaxAbsoluteEncoder.h"

#include <stdexcept>

#include "rev/CANSparkMax.h"
#include "rev/CANSparkMaxDriver.h"

using namespace rev;

SparkMaxAbsoluteEncoder::SparkMaxAbsoluteEncoder(CANSparkMax& device, Type type)
    : AbsoluteEncoder(), m_device(&device) {
    if (c_SparkMax_AttemptToSetDataPortConfig(
            static_cast<c_SparkMax_handle>(m_device->m_sparkMaxHandle),
            c_SparkMax_kDataPortConfigLimitSwitchesAndAbsoluteEncoder) ==
        c_REVLibError_SparkMaxDataPortAlreadyConfiguredDifferently) {
        throw std::runtime_error(fmt::format(
            "An absolute encoder cannot be used on SPARK MAX #{}, because it "
            "has an alternate encoder configured",
            m_device->m_deviceID));
    }
}

double SparkMaxAbsoluteEncoder::GetPosition() const {
    float tmp;

    c_SparkMax_GetDutyCyclePosition(
        static_cast<c_SparkMax_handle>(m_device->m_sparkMaxHandle), &tmp);
    return static_cast<double>(tmp);
}

double SparkMaxAbsoluteEncoder::GetVelocity() const {
    float tmp;

    c_SparkMax_GetDutyCycleVelocity(
        static_cast<c_SparkMax_handle>(m_device->m_sparkMaxHandle), &tmp);
    return static_cast<double>(tmp);
}

REVLibError SparkMaxAbsoluteEncoder::SetPositionConversionFactor(
    double factor) {
    c_REVLib_ErrorCode status;

    status = c_SparkMax_SetDutyCyclePositionFactor(
        static_cast<c_SparkMax_handle>(m_device->m_sparkMaxHandle), factor);
    return static_cast<REVLibError>(status);
}

double SparkMaxAbsoluteEncoder::GetPositionConversionFactor() const {
    float tmp;

    c_SparkMax_GetDutyCyclePositionFactor(
        static_cast<c_SparkMax_handle>(m_device->m_sparkMaxHandle), &tmp);
    return static_cast<double>(tmp);
}

REVLibError SparkMaxAbsoluteEncoder::SetVelocityConversionFactor(
    double factor) {
    c_REVLib_ErrorCode status;

    status = c_SparkMax_SetDutyCycleVelocityFactor(
        static_cast<c_SparkMax_handle>(m_device->m_sparkMaxHandle), factor);
    return static_cast<REVLibError>(status);
}

double SparkMaxAbsoluteEncoder::GetVelocityConversionFactor() const {
    float tmp;

    c_SparkMax_GetDutyCycleVelocityFactor(
        static_cast<c_SparkMax_handle>(m_device->m_sparkMaxHandle), &tmp);
    return static_cast<double>(tmp);
}

REVLibError SparkMaxAbsoluteEncoder::SetInverted(bool inverted) {
    c_REVLib_ErrorCode status;

    status = c_SparkMax_SetDutyCycleInverted(
        static_cast<c_SparkMax_handle>(m_device->m_sparkMaxHandle), inverted);
    return static_cast<REVLibError>(status);
}

bool SparkMaxAbsoluteEncoder::GetInverted() const {
    uint8_t tmp;

    c_SparkMax_GetDutyCycleInverted(
        static_cast<c_SparkMax_handle>(m_device->m_sparkMaxHandle), &tmp);
    return tmp ? true : false;
}

REVLibError SparkMaxAbsoluteEncoder::SetAverageDepth(uint32_t depth) {
    c_REVLib_ErrorCode status;

    int depthIndex;
    switch (depth) {
        case 1:
            depthIndex = 0;
            break;
        case 2:
            depthIndex = 1;
            break;
        case 4:
            depthIndex = 2;
            break;
        case 8:
            depthIndex = 3;
            break;
        case 16:
            depthIndex = 4;
            break;
        case 32:
            depthIndex = 5;
            break;
        case 64:
            depthIndex = 6;
            break;
        case 128:
            depthIndex = 7;
            break;
        default:
            throw std::invalid_argument(
                "Depth must be a bit size of either 1, 2, 4, 8, 16, 32, 64, or "
                "128");
    }

    status = c_SparkMax_SetDutyCycleAverageDepth(
        static_cast<c_SparkMax_handle>(m_device->m_sparkMaxHandle), depthIndex);
    return static_cast<REVLibError>(status);
}

uint32_t SparkMaxAbsoluteEncoder::GetAverageDepth() const {
    uint32_t tmp;

    c_SparkMax_GetDutyCycleAverageDepth(
        static_cast<c_SparkMax_handle>(m_device->m_sparkMaxHandle), &tmp);

    switch (tmp) {
        case 0:
            return 1;
        case 1:
            return 2;
        case 2:
            return 4;
        case 3:
            return 8;
        case 4:
            return 16;
        case 5:
            return 32;
        case 6:
            return 64;
        case 7:
            return 128;
        default:
            return 0;
    }
}

#if 0
REVLibError SparkMaxAbsoluteEncoder::SetSampleDelta(uint32_t delta) {
    c_REVLib_ErrorCode status;

    status = c_SparkMax_SetDutyCycleSampleDelta(
        static_cast<c_SparkMax_handle>(m_device->m_sparkMaxHandle), delta);
    return static_cast<REVLibError>(status);
}

uint32_t SparkMaxAbsoluteEncoder::GetSampleDelta() const {
    uint32_t tmp;

    c_SparkMax_GetDutyCycleSampleDelta(
        static_cast<c_SparkMax_handle>(m_device->m_sparkMaxHandle), &tmp);
    return static_cast<uint32_t>(tmp);
}
#endif

REVLibError SparkMaxAbsoluteEncoder::SetZeroOffset(double offset) {
    c_REVLib_ErrorCode status;

    // Remove position conversion factor to get a [0, 1] range
    double absoluteOffset = offset / GetPositionConversionFactor();

    status = c_SparkMax_SetDutyCycleOffset(
        static_cast<c_SparkMax_handle>(m_device->m_sparkMaxHandle),
        absoluteOffset);
    return static_cast<REVLibError>(status);
}

double SparkMaxAbsoluteEncoder::GetZeroOffset() const {
    float tmp;

    c_SparkMax_GetDutyCycleOffset(
        static_cast<c_SparkMax_handle>(m_device->m_sparkMaxHandle), &tmp);

    // Apply position conversion factor to return value
    return static_cast<double>(tmp) * GetPositionConversionFactor();
}

int SparkMaxAbsoluteEncoder::GetSparkMaxFeedbackDeviceID() const {
    return static_cast<int>(
        CANSparkMaxLowLevel::FeedbackSensorType::kDutyCycleSensor);
}
